package com.crewandrole.management_system.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.Setter;

@Entity
@Getter @Setter
@Table(name="role_table")
public class RoleEntity {
   
   @Id
   @Column(length = 15)
   private String pk_roleid;

   @Column(length = 30) 
   private String name;

   @Column(length = 250)
   private String description;

   public RoleEntity(String roleid, String name, String description) {
      this.pk_roleid = roleid;
      this.name = name;
      this.description = description;
   }
   public RoleEntity(){

   }

   @Override
   public String toString() {
      return "RoleEntity [roleid=" + pk_roleid + ", name=" + name + ", description=" + description + "]";
   }

}
