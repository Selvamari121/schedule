package com.crewandrole.management_system.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.Setter;

@Entity
@Getter @Setter
@Table(name="crewtable")
public class CrewEntity {
   @Id
   @Column(length = 15)
   private String pk_crid;

   @Column(length = 15) 
   private String fk_phid;

   @Column(length = 15)
   private String fk_roleid;

   @Column(length = 15) 
   private String name;

   @Column(length = 50)
   private String email;

   @Column(length = 10) 
   private String mobile;

   @Column(length = 10)
   private String pan;

   public CrewEntity(String pk_crid, String fk_phid, String fk_roleid, String name, String email, String mobile, String pan) {
      this.pk_crid = pk_crid;
      this.fk_phid = fk_phid;
      this.fk_roleid = fk_roleid;
      this.name = name;
      this.email = email;
      this.mobile = mobile;
      this.pan = pan;
   }
   public CrewEntity(){

   } 

   @Override
   public String toString() {
      return "CrewEntity [crid=" + pk_crid + ", phid=" + fk_phid + ", roleid=" + fk_roleid + ", name=" + name + ", email="
            + email + ", mobile=" + mobile + ", pan=" + pan + "]";
   }
}
