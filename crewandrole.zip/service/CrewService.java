package com.crewandrole.management_system.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.crewandrole.management_system.model.CrewEntity;
import com.crewandrole.management_system.repo.CrewRepository;
import jakarta.persistence.EntityNotFoundException;

@Service
public class CrewService {
   @Autowired
   private CrewRepository repo;

   public CrewEntity saveCrew(CrewEntity crew) {
      return repo.save(crew);
   }

   public CrewEntity getCrewById(String pk_crid) {
      return repo.findById(pk_crid).orElseThrow(() -> new EntityNotFoundException("Crew not found with id " + pk_crid));
   }
   
   public List<CrewEntity> findAllCrews() {
      List<CrewEntity> Crews = repo.findAll();
      if (Crews.isEmpty()) {
         throw new EntityNotFoundException("No Photography Crew found");
      }
      return Crews;
   }

   public void deleteCrewById(String pk_crid) {
      if (repo.existsById(pk_crid)) {
         repo.deleteById(pk_crid);
      } else {
         throw new EntityNotFoundException("Crew not found with id " + pk_crid);
      }
   }
  
   public CrewEntity updateCrew(String pk_crid, CrewEntity updatedCrew) {
      return repo.findById(pk_crid).map(existingCrew -> {
         existingCrew.setName(updatedCrew.getName());
         existingCrew.setEmail(updatedCrew.getEmail());
         existingCrew.setFk_roleid(updatedCrew.getFk_roleid());
         existingCrew.setMobile(updatedCrew.getMobile());
         existingCrew.setPan(updatedCrew.getPan());
         return repo.save(existingCrew);
      }).orElseThrow();
   }  
}
