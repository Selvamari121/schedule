package com.crewandrole.management_system.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.crewandrole.management_system.model.RoleEntity;
import com.crewandrole.management_system.repo.RoleRepository;
import jakarta.persistence.EntityNotFoundException;

@Service
public class RoleService {
   @Autowired
   private RoleRepository repository;

   public void saveRole(RoleEntity role) {
      repository.save(role);
   }  
   
   public RoleEntity getRoleById(String pk_roleid) {
      return repository.findById(pk_roleid).orElseThrow(() -> new EntityNotFoundException("Role not found with id " + pk_roleid));
   }

   
   public List<RoleEntity> findAllRoles() {
      List<RoleEntity> roles = repository.findAll();
      if (roles.isEmpty()) {
         throw new EntityNotFoundException("No Photography Roles found");
      }
      return roles;
   }

   public void deleteRoleById(String pk_roleid) {
      if (repository.existsById(pk_roleid)) {
         repository.deleteById(pk_roleid);
      } else {
         throw new EntityNotFoundException("Role not found with id " + pk_roleid);
      }
   }

   public RoleEntity updatedRole(String pk_roleid, RoleEntity updatedRole) {
      return repository.findById(pk_roleid).map(existingRole -> {
         existingRole.setName(updatedRole.getName());
         existingRole.setDescription(updatedRole.getDescription());
         return repository.save(existingRole);
      }).orElseThrow(() -> new EntityNotFoundException("Role not found"));
   }
}

