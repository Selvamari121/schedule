package com.crewandrole.management_system.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.crewandrole.management_system.model.RoleEntity;
import com.crewandrole.management_system.service.RoleService;

@RestController
@RequestMapping("/role")
public class RoleController {
   @Autowired
   private RoleService service; 

   @PostMapping("/addrole")
   public ResponseEntity<String> addRole(@RequestBody RoleEntity role) {
      //System.out.println(role);
      service.saveRole(role);
      return ResponseEntity.status(HttpStatus.CREATED).build();
   }

   @GetMapping("/view/{pk_roleid}")
   public ResponseEntity<RoleEntity> getRoleById(@PathVariable String pk_roleid) {
      RoleEntity roles = service.getRoleById(pk_roleid);
      return ResponseEntity.ok(roles);
   }

   @GetMapping("/view/all")
   public ResponseEntity<List<RoleEntity>> findAllRoles(){
      List<RoleEntity> roles = service.findAllRoles();
      return ResponseEntity.ok(roles);
   }

   @DeleteMapping("/deleterole/{pk_roleid}")
   public ResponseEntity<Void> deleteRoleById(@PathVariable String pk_roleid) {
      service.deleteRoleById(pk_roleid);
      return ResponseEntity.noContent().build();  
   }

   @PutMapping("/editrole/{pk_roleid}")
   public ResponseEntity<RoleEntity> updatedRole(@PathVariable String pk_roleid, @RequestBody RoleEntity updatedRole) {
      RoleEntity updatedRoles = service.updatedRole(pk_roleid, updatedRole);
      return ResponseEntity.ok(updatedRoles);
   }
}




   // @GetMapping("/view/{crid}")
   // public ResponseEntity<CrewEntity> getCrewById(@PathVariable String crid) {
   //    CrewEntity crew = service.getCrewById(crid);
   //    return ResponseEntity.ok(crew);
   // }
