package com.payment.schedule;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.test.context.SpringBootTest;
import com.payment.schedule.model.Schedule;
import com.payment.schedule.repo.ScheduleRepo;
import com.payment.schedule.service.ScheduleService;

@SpringBootTest
public class ScheduleServiceTest {

   @InjectMocks
   private ScheduleService scheduleService;

   @Mock
   private ScheduleRepo scheduleRepo;

   private Schedule testSchedule;

   @BeforeEach
   public void setUp() {
      MockitoAnnotations.openMocks(this);
      testSchedule = new Schedule();
      testSchedule.setSchedule_id(1L);
      testSchedule.setTotal_amount(100.0);
      testSchedule.setSchedule_amount(50.0);
      testSchedule.setPayment_due_date(LocalDate.of(2024, 8, 28));
      testSchedule.setIs_paid(false);
      testSchedule.setPayment_date(null);
      testSchedule.setProject_id(10L);
   }

   @Test
   public void saveSchedule() {
      when(scheduleRepo.save(testSchedule)).thenReturn(testSchedule);
      scheduleService.saveSchedule(testSchedule);
      verify(scheduleRepo, times(1)).save(testSchedule);
   }

   @Test
   public void getScheduleById() {
      when(scheduleRepo.findById(1L)).thenReturn(Optional.of(testSchedule));
      Schedule schedule = scheduleService.getScheduleById(1L);
      assertNotNull(schedule);
      assertEquals(1L, schedule.getSchedule_id());
   }
   @Test
   public void findAllSchedules() {
      List<Schedule> schedules = new ArrayList<>();
      schedules.add(testSchedule);
      when(scheduleRepo.findAll()).thenReturn(schedules);
      List<Schedule> result = scheduleService.findAllSchedules();
      assertFalse(result.isEmpty());
      assertEquals(1, result.size());
   }

   @Test
   public void deleteScheduleById() {
      when(scheduleRepo.existsById(1L)).thenReturn(true);
      scheduleService.deleteScheduleById(1L);
      verify(scheduleRepo, times(1)).deleteById(1L);
   }

   @Test
   public void pdatePaymentSchedule() {
      Schedule updatedSchedule = new Schedule();
      updatedSchedule.setTotal_amount(200.0);
      updatedSchedule.setSchedule_amount(100.0);
      updatedSchedule.setPayment_due_date(LocalDate.of(2024, 8, 28));
      updatedSchedule.setIs_paid(true);
      updatedSchedule.setPayment_date(LocalDate.of(2024, 8, 28));
      updatedSchedule.setProject_id(20L);
      when(scheduleRepo.findById(1L)).thenReturn(Optional.of(testSchedule));
      when(scheduleRepo.save(any(Schedule.class))).thenReturn(updatedSchedule);
      Schedule result = scheduleService.updatePaymentSchedule(1L, updatedSchedule);
      assertNotNull(result);
      assertEquals(200.0, result.getTotal_amount());
      assertEquals(100.0, result.getSchedule_amount());
      assertEquals(LocalDate.of(2024, 8, 28), result.getPayment_due_date());
      assertTrue(result.getIs_paid());
      assertEquals(LocalDate.of(2024, 8, 28), result.getPayment_date());
      assertEquals(20L, result.getProject_id());
   }
}

