package com.payment.schedule;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.delete;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.BDDMockito.given;
import static org.mockito.BDDMockito.then;
import static org.mockito.Mockito.when;
import org.springframework.http.MediaType;
import java.time.LocalDate;
import java.util.List;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import com.payment.schedule.controller.ScheduleController;
import com.payment.schedule.model.Schedule;
import com.payment.schedule.service.ScheduleService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.web.servlet.MockMvc;

@WebMvcTest(ScheduleController.class)
public class ScheduleControllerTest {
    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private ScheduleService service;

    @Autowired
    private ObjectMapper objectMapper;

    @BeforeEach                                            
    public void setup() {
        objectMapper.registerModule(new JavaTimeModule());
    }

    @Test
    public void addSchedule() throws Exception {
        Schedule schedule = new Schedule();
        schedule.setTotal_amount(100.0);
        schedule.setSchedule_amount(50.0);
        schedule.setPayment_due_date(LocalDate.of(2024, 8, 28));  
        schedule.setIs_paid(false);
        schedule.setPayment_due_date(null); 
        schedule.setProject_id( 10L);

        String json = objectMapper.writeValueAsString(schedule);

        mockMvc.perform(post("/schedule/create")
                .contentType("application/json")
                .content(json))
                .andExpect(status().isCreated());
    }

    @Test
    public void getScheduleById() throws Exception {
        Schedule schedule = new Schedule();
        schedule.setSchedule_id(1L);
        schedule.setTotal_amount(100.0);
        schedule.setSchedule_amount(50.0);
        schedule.setPayment_due_date(LocalDate.of(2024, 8, 28));
        schedule.setIs_paid(false);
        schedule.setPayment_date(null);
        schedule.setProject_id(10L);

        given(service.getScheduleById(1L)).willReturn(schedule);

        mockMvc.perform(get("/schedule/view/1"))
                .andExpect(status().isOk())
                .andExpect(content().contentType(MediaType.APPLICATION_JSON))
                .andExpect(jsonPath("$.total_amount").value(100.0))
                .andExpect(jsonPath("$.schedule_amount").value(50.0))
                .andExpect(jsonPath("$.payment_due_date").value("2024-08-28"))
                .andExpect(jsonPath("$.is_paid").value(false))
                .andExpect(jsonPath("$.project_id").value(10L));
    }
    
    @Test
    public void getAllSchedules() throws Exception {
        Schedule schedule = new Schedule();
        schedule.setTotal_amount(100.0);
        schedule.setSchedule_amount(50.0);
        schedule.setPayment_due_date(LocalDate.of(2024, 8, 28));
        schedule.setIs_paid(false);
        schedule.setPayment_date(null);
        schedule.setProject_id(10L);

        given(service.findAllSchedules()).willReturn(List.of(schedule));

        mockMvc.perform(get("/schedule/view/all"))
                .andExpect(status().isOk())
                .andExpect(content().contentType(MediaType.APPLICATION_JSON))
                .andExpect(jsonPath("$[0].total_amount").value(100.0))
                .andExpect(jsonPath("$[0].schedule_amount").value(50.0))
                .andExpect(jsonPath("$[0].payment_due_date").value("2024-08-28"))
                .andExpect(jsonPath("$[0].is_paid").value(false))
                .andExpect(jsonPath("$[0].project_id").value(10L));
    }

    @Test
    public void deleteScheduleById() throws Exception {
        mockMvc.perform(delete("/schedule/delete/1"))
                .andExpect(status().isNoContent());
        then(service).should().deleteScheduleById(1L);
    }
    @Test
    public void updatePaymentSchedule() throws Exception {
        Long schedule_id = 1L;
        Schedule updated = new Schedule();
        updated.setTotal_amount(200.0);
        updated.setSchedule_amount(100.0);
        updated.setPayment_due_date(LocalDate.of(2024, 8, 28));
        updated.setIs_paid(true);
        updated.setPayment_date(LocalDate.of(2024, 8, 28));
        updated.setProject_id(20L);
        
        when(service.updatePaymentSchedule(eq(schedule_id), any(Schedule.class))).thenReturn(updated);

        mockMvc.perform(put("/schedule/edit/1")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(updated)))
                    //             .content("{\"total_amount\":150.0,\"schedule_amount\":75.0,\"payment_due_date\":\"2024-09-01\",\"is_paid\":false,\"project_id\":2}"))
                .andExpect(status().isOk())
                .andExpect(content().contentType(MediaType.APPLICATION_JSON))
                .andExpect(jsonPath("$.total_amount").value(200.0))
                .andExpect(jsonPath("$.schedule_amount").value(100.0))
                .andExpect(jsonPath("$.payment_due_date").value("2024-08-28"))
                .andExpect(jsonPath("$.is_paid").value(true))
                .andExpect(jsonPath("$.payment_date").value("2024-08-28"))
                .andExpect(jsonPath("$.project_id").value(20L));
    }
}

