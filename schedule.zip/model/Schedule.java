package com.payment.schedule.model;

import java.time.LocalDate;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.Setter;

@Entity
@Getter @Setter
@Table(name="paymentschedules")
public class Schedule {
   @Id
   @GeneratedValue(strategy = GenerationType.IDENTITY)
   private Long schedule_id;

   @Column(nullable = false)  
   private Double total_amount;

   @Column
   private Double schedule_amount;

   @Column  
   private LocalDate payment_due_date ;

   @Column(nullable = false) 
   private Boolean is_paid;

   @Column
   private LocalDate payment_date ;

   @Column(nullable = false)
   private Long project_id;

   public Schedule(Long schedule_id, Double total_amount, Double schedule_amount, LocalDate payment_due_date,
         Boolean is_paid, LocalDate payment_date, Long project_id) {
      this.schedule_id = schedule_id;
      this.total_amount = total_amount;
      this.schedule_amount = schedule_amount;
      this.payment_due_date = payment_due_date;
      this.is_paid = is_paid;
      this.payment_date = payment_date;
      this.project_id = project_id;
   }

   public Schedule(){
      
   }
   @Override
   public String toString() {
      return "Schedule [schedule_id=" + schedule_id + ", total_amount=" + total_amount + ", schedule_amount="
            + schedule_amount + ", payment_due_date=" + payment_due_date + ", is_paid=" + is_paid + ", payment_date="
            + payment_date + ", project_id=" + project_id + "]";
   }


}