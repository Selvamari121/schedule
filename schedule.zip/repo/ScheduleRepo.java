package com.payment.schedule.repo;

// import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
// import org.springframework.data.jpa.repository.Query;
import com.payment.schedule.model.Schedule;

public interface ScheduleRepo extends JpaRepository<Schedule, Long> {
   // @Query("select s from Schedule s where s.prid = ?1")
   // List<Schedule> findByPrid(Long prid);
   // List<Schedule> findByPaymentDueDate(LocalDate paymentDueDate);
   // List<Schedule> findByIsPaid(Boolean isPaid);
   // List<Schedule> findByScheduleAmountGreaterThan(Double amount);
   // List<Schedule> findByTotalAmountBetween(Double minAmount, Double maxAmount);
   // List<Schedule> findByPaymentDateAfter(LocalDate date);
   // List<Schedule> findByPaymentDateBefore(LocalDate date);
   // List<Schedule> findByPridAndIsPaid(Long prid, Boolean isPaid);
   // List<Schedule> findByIsPaidFalseAndPaymentDueDateBefore(LocalDate dueDate);
   
}
