package com.crewandrole.management_system;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.Mockito.*;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import com.crewandrole.management_system.model.RoleEntity;
import com.crewandrole.management_system.repo.RoleRepository;
import com.crewandrole.management_system.service.RoleService;

import java.util.List;
import java.util.Optional;

@ExtendWith(MockitoExtension.class)
class RoleServiceTest {

   @Mock
   private RoleRepository repository;

   @InjectMocks
   private RoleService service;

   @Test
   void saveRole() {
      RoleEntity role = new RoleEntity("ADMIN", "Admin", "Administrator role");
      service.saveRole(role);
      verify(repository, times(1)).save(role);
   }
   @Test
   void getRoleById() {
      RoleEntity role = new RoleEntity("ADMIN", "Admin", "Administrator role");
      when(repository.findById("ADMIN")).thenReturn(Optional.of(role));
      RoleEntity result = service.getRoleById("ADMIN");
      assertEquals(role, result);
   }
   @Test
   public void findAllRoles() {
      List<RoleEntity> roles = List.of(new RoleEntity(), new RoleEntity());
      when(repository.findAll()).thenReturn(roles);
      List<RoleEntity> result = service.findAllRoles();
      assertNotNull(result);
      assertEquals(roles.size(), result.size());
   }
   @Test
   void deleteRoleById() {
      String pk_roleid = "ADMIN";
      when(repository.existsById(pk_roleid)).thenReturn(true);
      service.deleteRoleById(pk_roleid);
      verify(repository, times(1)).deleteById(pk_roleid);
   }

   @Test
   void updatedRole() {
      String pk_roleid = "ADMIN";
      RoleEntity existingRole = new RoleEntity(pk_roleid, "Admin", "Administrator role");
      RoleEntity updatedRole = new RoleEntity(pk_roleid, "Admin Updated", "Updated role description");
      when(repository.findById(pk_roleid)).thenReturn(Optional.of(existingRole));
      when(repository.save(existingRole)).thenReturn(existingRole);
      RoleEntity result = service.updatedRole(pk_roleid, updatedRole);
      assertEquals("Admin Updated", result.getName());
      assertEquals("Updated role description", result.getDescription());
      verify(repository, times(1)).save(existingRole);
   }
}



   //  @Test
   //  void deleteRoleById_shouldThrowExceptionWhenNotExists() {
   //      String roleId = "ADMIN";
   //      when(repository.existsById(roleId)).thenReturn(false);

   //      assertThrows(EntityNotFoundException.class, () -> service.deleteRoleById(roleId));
   //  }

//  @Test
   //  void updatedRole_shouldThrowExceptionWhenRoleNotFound() {
   //      String roleId = "ADMIN";
   //      RoleEntity updatedRole = new RoleEntity(roleId, "Admin Updated", "Updated role description");

   //      when(repository.findById(roleId)).thenReturn(Optional.empty());

   //      assertThrows(RuntimeException.class, () -> service.updatedRole(roleId, updatedRole));
   //  }


