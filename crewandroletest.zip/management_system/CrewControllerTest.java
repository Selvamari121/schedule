package com.crewandrole.management_system;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;
import java.util.Arrays;
import java.util.List;
import org.springframework.http.MediaType;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.web.servlet.MockMvc;
import com.crewandrole.management_system.controller.CrewController;
import com.crewandrole.management_system.model.CrewEntity;
import com.crewandrole.management_system.service.CrewService;
import com.fasterxml.jackson.databind.ObjectMapper;

@WebMvcTest(CrewController.class)
class CrewControllerTest {

   @Autowired
   private MockMvc mockMvc;

   @MockBean
   private CrewService service;

   @Autowired
   private ObjectMapper objectMapper;
   private CrewEntity crew;

   @BeforeEach
   public void setup() {
      crew = new CrewEntity();
      crew.setPk_crid("CR01");
      crew.setFk_phid("PH01");
      crew.setFk_roleid("ADMIN");
      crew.setName("John Doe");
      crew.setEmail("john@example.com");
      crew.setMobile("1234567890");
      crew.setPan("ABCDE1234F");
   }

   @Test
   public void addCrew() throws Exception {
      mockMvc.perform(post("/crew/addcrew")
               .contentType(MediaType.APPLICATION_JSON)
               .content(objectMapper.writeValueAsString(crew)))
               .andExpect(status().isCreated());
      verify(service, times(1)).saveCrew(any(CrewEntity.class));
   }

   @Test
   public void getCrewById() throws Exception {
      when(service.getCrewById("CR01")).thenReturn(crew);

      mockMvc.perform(get("/crew/view/{pk_crid}", "CR01")
               .contentType(MediaType.APPLICATION_JSON))
               .andExpect(status().isOk())
               .andExpect(jsonPath("$.pk_crid").value(crew.getPk_crid()))  
               .andExpect(jsonPath("$.fk_phid").value(crew.getFk_phid()))
               .andExpect(jsonPath("$.fk_roleid").value(crew.getFk_roleid()))
               .andExpect(jsonPath("$.name").value(crew.getName()))
               .andExpect(jsonPath("$.email").value(crew.getEmail()))
               .andExpect(jsonPath("$.mobile").value(crew.getMobile()))
               .andExpect(jsonPath("$.pan").value(crew.getPan()));

      verify(service, times(1)).getCrewById("CR01");
   }
   @Test
   public void findAllCrews() throws Exception {
      List<CrewEntity> crews = Arrays.asList(crew);
      when(service.findAllCrews()).thenReturn(crews);
      mockMvc.perform(get("/crew/view/all")
      .contentType(MediaType.APPLICATION_JSON))
      .andExpect(status().isOk())
      .andExpect(jsonPath("$[0].pk_crid").value(crew.getPk_crid()))  
      .andExpect(jsonPath("$[0].fk_phid").value(crew.getFk_phid()))
      .andExpect(jsonPath("$[0].fk_roleid").value(crew.getFk_roleid()))
      .andExpect(jsonPath("$[0].name").value(crew.getName()))
      .andExpect(jsonPath("$[0].email").value(crew.getEmail()))
      .andExpect(jsonPath("$[0].mobile").value(crew.getMobile()))
      .andExpect(jsonPath("$[0].pan").value(crew.getPan()));

      verify(service, times(1)).findAllCrews();
   }

   @Test
   public void deleteCrewById() throws Exception {
      mockMvc.perform(delete("/crew/deletecrew/CR01"))
             .andExpect(status().isNoContent());

      verify(service, times(1)).deleteCrewById("CR01");
   }
   @Test
   void updateCrew() throws Exception {
      String pk_crid = "CR01";
      CrewEntity updatedRole = new CrewEntity(pk_crid, "PH01", "ADMINS","Doe","doe@example.com","1234576890","ABCDE4546F");
      when(service.updateCrew(eq(pk_crid), any( CrewEntity.class))).thenReturn(updatedRole);
      mockMvc.perform(put("/crew/editcrew/{pk_crid}", pk_crid)
      .contentType(MediaType.APPLICATION_JSON)
      .content(objectMapper.writeValueAsString(updatedRole)))
      .andExpect(status().isOk())
      .andExpect(jsonPath("$.pk_crid").value(pk_crid))  
      .andExpect(jsonPath("$.fk_phid").value("PH01"))
      .andExpect(jsonPath("$.fk_roleid").value("ADMINS"))
      .andExpect(jsonPath("$.name").value("Doe"))
      .andExpect(jsonPath("$.email").value("doe@example.com"))
      .andExpect(jsonPath("$.mobile").value("1234576890"))
      .andExpect(jsonPath("$.pan").value("ABCDE4546F"));
      verify(service, times(1)).updateCrew(eq(pk_crid), any(CrewEntity.class));
   }
}


